---
name: unbound-rpz
description: Configurar, revisar e diagnosticar Unbound DNS e RPZ, melhorar desempenho com medições e identificar configurações incorretas, versões obsoletas, bugs e CVEs aplicáveis. Usar em trabalhos de Unbound, unbound.conf, políticas RPZ, listas de bloqueio e incidentes de resolução desse serviço.
---

# Unbound DNS e RPZ

## Objetivo e preferência do usuário

Produzir mudanças verificáveis e documentação detalhada em português, preservando resolução, DNSSEC e políticas pretendidas. O usuário pediu atenção especial a desempenho, prevenção de erros, CVEs, bugs e versões obsoletas. Sempre relatar falhas encontradas, com evidências e caminho de correção. Criar esta skill não autoriza alterações futuras em servidores sem uma tarefa correspondente.

## Escolher a referência necessária

- Antes de mudar configuração ou investigar incidente: [operação e diagnóstico](references/operacao.md).
- Para regras, exceções, alimentação e testes de RPZ: [políticas RPZ](references/rpz.md).
- Para latência, capacidade, cache e consumo: [desempenho](references/desempenho.md).
- Para versão obsoleta, bug conhecido, atualização e CVEs: [segurança e relatório de falhas](references/seguranca.md).
- Fontes oficiais e critérios de atualização: [fontes](references/fontes.md).

Leia apenas as referências pertinentes. Antes de aplicar opções ou comandos dependentes de versão, confronte com a versão instalada, o manual local e a documentação oficial. Não trate páginas `latest` como prova de suporte numa instalação antiga.

## Descoberta que orienta as decisões

Identifique, preferencialmente por leitura do ambiente:

1. Host ou cluster correto, sistema, distribuição/release e método de instalação.
2. Versão do binário **em execução**, versão completa do pacote, origem e correções do fornecedor.
3. Arquivo principal realmente carregado, cadeia de includes, usuário do daemon, chroot e serviço/container responsável.
4. Modo: recursivo, encaminhador, upstream de Pi-hole, appliance ou resolver com proxy à frente.
5. Interfaces, portas, ACLs, IPv4/IPv6, domínio interno, DNSSEC, DoT/DoH e dependências de inicialização.
6. RPZs na ordem efetiva, origem de cada feed, frequência de atualização e quantidade aproximada de regras.
7. CPU/RAM e limites do container, carga, sintomas, horário e impacto relatado.

Não confunda este ambiente de trabalho com o servidor DNS do usuário. Se o destino não estiver disponível, produza arquivos/procedimentos revisáveis e diga quais validações precisam ocorrer no destino. Pergunte somente pelo contexto indispensável que não puder descobrir.

## Fluxo de mudança

1. Registre estado inicial, sintomas e resultado esperado; consulte avisos de segurança ao avaliar versão ou manutenção.
2. Preserve a configuração funcional e os arquivos alterados, com permissões e procedência. Em appliances, trabalhe na fonte gerenciada; em GitOps, nos manifests.
3. Prepare uma mudança limitada, com diferença revisável e instrução concreta de reversão.
4. Valide a configuração principal candidata e seus includes com `unbound-checkconf`. Código zero é condição necessária, não comprovação de funcionamento ou de todas as zonas RPZ.
5. Quando necessário, carregue a candidata numa instância isolada, sem disputar porta, PID, controle, arquivos graváveis ou trust anchor com produção. Adapte chroot e permissões sem enfraquecer produção.
6. Aplique somente no destino e escopo autorizados. Escolha recarga/reinício conforme suporte, efeito no cache e necessidade da mudança.
7. Confirme logs, serviço ativo e testes funcionais diretos e pelo caminho dos clientes. Compare desempenho somente com carga comparável.
8. Se falhar, restaure o último estado funcional dentro do escopo da mudança, valide e reporte. Não repita implantação de uma candidata sabidamente inválida.

## Invariantes técnicos

- A política RPZ precisa do módulo `respip`; a cadeia básica usual é `respip validator iterator`. Preserve módulos adicionais e verifique a ordem documentada. `respip` não é o módulo de EDNS Client Subnet.
- Slabs são partições do cache compartilhado, não mecanismo de sincronização entre caches de processos independentes.
- DNSSEC valida autenticidade de dados DNS; DoT/DoH protegem o transporte. Um encaminhador não precisa assinar novamente respostas para o Unbound validar dados DNSSEC.
- Um `SERVFAIL` não prova problema de DNSSEC. `+cdflag` é uma comparação diagnóstica, não uma correção de produção.
- Não desative DNSSEC, IPv6, chroot ou controles de acesso como correção genérica. Exceções precisam de causa comprovada, escopo mínimo e justificativa.
- Cache aquecido e `serve-expired` podem esconder falhas. Consultar diretamente Unbound elimina caches anteriores, mas não o cache do próprio Unbound.
- Uma recarga pode esvaziar cache, consumir memória adicional e interromper serviço; nunca prometa ausência de impacto sem evidência.
- Não presuma que maior número de threads, TTLs elevados, Redis ou mais listas sempre melhoram o serviço.

## Entrega esperada

Apresente resultado, mudanças, validações executadas e limitações. Para documentos operacionais, inclua pré-requisitos, caminhos reais, comandos contextualizados, resultado esperado e reversão. Separe fatos medidos de hipóteses.

Ao encontrar versão obsoleta, bug ou CVE, **reporte mesmo que a correção esteja fora do escopo atual**. Use o modelo da referência de segurança. Não declare vulnerabilidade confirmada apenas pelo banner; considere backports e condições de exploração. Não publique logs ou relatórios em serviços externos sem autorização específica.

Esta skill orienta trabalhos futuros; não instala monitoramento periódico nem garante ausência de bugs ou vulnerabilidades.
