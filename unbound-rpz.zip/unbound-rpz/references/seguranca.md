# Segurança, versões obsoletas, bugs e CVEs

## Regra solicitada pelo usuário

Sempre que encontrar versão obsoleta, bug conhecido, vulnerabilidade aplicável ou configuração incorreta, relate a falha para que possa ser corrigida. Dê evidências, impacto e orientação de correção; não transforme indício em confirmação. O relatório padrão é entregue ao usuário/no artefato de trabalho. Abrir issue, enviar e-mail ou publicar detalhes exige autorização para essa ação externa.

## 1. Identificar o software real

Reúna sistema/release, arquitetura, versão do processo, versão completa do pacote e repositório. Exemplos de leitura, somente no sistema correspondente:

```bash
# Debian/Ubuntu
dpkg-query -W -f='${Package} ${Version} ${Architecture}\n' unbound
apt-cache policy unbound

# Distribuição RPM
rpm -q unbound

# FreeBSD
pkg info unbound
```

`apt-cache policy` usa metadados locais que podem estar antigos; não os apresente como última versão disponível sem conferir sua atualidade. Em FreeBSD/appliances pode existir Unbound no sistema base e outro via pacote; identifique o executável usado. Em container, registre digest e versão dentro da imagem, não apenas tag mutável como `latest`.

Diferencie:

- Versão upstream mais antiga que a atual: pode continuar mantida pelo fornecedor.
- Pacote com correção por backport: número upstream pode permanecer antigo.
- Release/distribuição sem suporte: risco de ficar sem correções, mesmo sem CVE específica comprovada.
- Pacote atualizado em disco com processo antigo: correção pode ainda não estar ativa.
- Bug funcional confirmado: pode não ter CVE nem impacto de segurança.

Não recomende compilar master ou misturar repositórios como correção padrão. Prefira atualização suportada pelo fornecedor e compatível com o ambiente.

## 2. Pesquisar a situação atual

Faça consulta atual durante uma avaliação de segurança/versão. Uma lista congelada de CVEs dentro desta skill ficaria incompleta rapidamente.

Ordem de evidência:

1. Avisos de segurança e release notes da NLnet Labs.
2. Tracker/aviso do fornecedor da distribuição ou appliance para o pacote e release exatos.
3. Registro CVE/CNA e, como complemento, NVD/CISA quando houver informação relevante.
4. Issue, commit e release oficial para bugs sem CVE.

Fontes estão em [fontes.md](fontes.md). Registre data da consulta e links diretos. Se houver contradição, descreva as fontes e a incerteza; não escolha apenas a maior nota de severidade. Falta de acesso à fonte significa verificação pendente, não ausência de vulnerabilidades.

## 3. Decidir aplicabilidade

Para cada achado, confira:

- Intervalo afetado e primeira versão corrigida conforme o aviso.
- Status no release/pacote exato, incluindo backports e patches do fornecedor.
- Condições: módulos habilitados, RPZ, serve-expired, DNSSEC, transporte, opções e dependências relevantes.
- Alcance: cliente direto, resposta de servidor autoritativo, feed ou operador local. Resolver não público ainda pode processar resposta maliciosa de uma zona externa.
- Impacto descrito: indisponibilidade, alteração de política, envenenamento, perda de confidencialidade ou execução de código. Não extrapole impacto.
- Evidência de exploração conhecida somente quando houver fonte que a sustente.

Use status claros: **afetado confirmado**, **potencialmente afetado**, **corrigido por backport**, **não aplicável pelas condições verificadas** ou **verificação pendente**. Uma configuração não afetada por um gatilho específico não prova segurança geral da instalação.

CVSS, quando citado, precisa de versão/valor/fonte; não atribua severidade inventada como nota oficial. Prioridade operacional considera exposição, impacto, disponibilidade de correção e criticidade do serviço.

## 4. Reportar versões obsoletas e bugs

Se chamar uma versão de obsoleta, indique o critério: fim de suporte do fornecedor, ramo abandonado, correções relevantes ausentes ou incompatibilidade documentada. Evite classificar automaticamente tudo que não é a release mais nova como vulnerável.

Para bug conhecido, relacione sintoma, condição e versão com uma issue/release oficial. Uma issue parecida é um indício até haver correspondência suficiente. Confira se a correção foi apenas proposta, mesclada, lançada e finalmente incorporada pelo pacote. Não trate esses estados como equivalentes.

Para bug ainda não documentado, registre reprodução mínima, resultado esperado/obtido, logs sanitizados, configuração reduzida e ambiente. Não teste payloads de exploração contra produção para confirmar CVE. Uma verificação de versão/patch/configuração pode ser suficiente; reprodução potencialmente disruptiva deve ser isolada e autorizada.

## 5. Modelo de relatório

```text
Achado: descrição concreta da falha
Categoria: configuração / bug / obsolescência / CVE
Destino e componente: host ou serviço, sem segredos
Detectado em: data e fuso
Status: confirmado / potencial / corrigido por backport / não aplicável / pendente
Versão em execução: versão e origem verificadas
Pacote, distribuição ou imagem: release completa/digest quando disponível
Evidências: comandos e trechos sanitizados; arquivo/linha ou condição observada
Referências: aviso oficial, status do fornecedor, issue/commit/release
Aplicabilidade: condições exigidas, observadas e ainda não verificadas
Impacto: comportamento/serviço afetado, segundo evidência
Prioridade: justificativa operacional; CVSS separado quando houver fonte
Correção: pacote/release ou alteração concreta; requisitos de compatibilidade
Mitigação temporária: somente se documentada, com limites e efeitos colaterais
Validação: verificações antes/depois e resultado esperado
Reversão: estado preservado, procedimento e restrições
Pendências: ação fora do escopo, responsável se conhecido e próxima verificação
```

Para achados pequenos, compacte mantendo os campos necessários à decisão. Para atualização recomendada, informe versão corrigida comprovada para o fornecedor; se não conseguir confirmar, declare a pendência em vez de inventar um número.

## 6. Corrigir e comprovar

Antes da atualização, revise opções removidas/defaults alterados, módulos disponíveis e formato de dados. Preserve configuração e plano de retorno. Em HA, atualize uma réplica por vez quando a arquitetura permitir e teste-a antes de avançar.

Após atualização, valide a configuração com ferramentas da nova instalação, confirme o novo processo e repita testes de DNSSEC, RPZ, exceções, domínios internos e transportes utilizados. Compare recursos e erros se a correção puder afetar desempenho. Registre a evidência de correção do fornecedor e o resultado operacional; não declare ausência de todas as CVEs.

Corrija apenas dentro da tarefa autorizada. Quando a remediação exigir mudança adicional de escopo, entregue o achado e uma proposta concreta. Não instale atualizações, reinicie servidores ou crie tarefas periódicas só porque esta skill exige reportar falhas.
