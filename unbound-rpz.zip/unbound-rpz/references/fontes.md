# Fontes e manutenção das instruções

Referências consultadas para preparar esta skill em 2026-11-04. Esta data não representa auditoria de qualquer servidor do usuário.

## Fontes primárias

| Assunto | Fonte | Uso |
| --- | --- | --- |
| Opções e módulos | [unbound.conf](https://unbound.docs.nlnetlabs.nl/en/latest/manpages/unbound.conf.html) | Sintaxe, defaults, ordem e condições das opções. |
| Validação | [unbound-checkconf](https://unbound.docs.nlnetlabs.nl/en/latest/manpages/unbound-checkconf.html) | Escopo do validador e códigos de saída. |
| Controle e recarga | [unbound-control](https://unbound.docs.nlnetlabs.nl/en/latest/manpages/unbound-control.html) | Suporte a comandos, efeitos no cache e restrições. |
| RPZ | [Response Policy Zones](https://unbound.docs.nlnetlabs.nl/en/latest/topics/filtering/rpz.html) | Gatilhos, ações, precedência, tags e modo de observação. |
| Desempenho | [Performance Tuning](https://unbound.docs.nlnetlabs.nl/en/latest/topics/core/performance.html) | Referências de dimensionamento; interpretar conforme ambiente. |
| Cache expirado | [Serving Stale Data](https://unbound.docs.nlnetlabs.nl/en/latest/topics/core/serve-stale.html) | Diferenças de comportamento e alterações por versão. |
| Segurança upstream | [NLnet Labs Security Advisories](https://www.nlnetlabs.nl/projects/unbound/security-advisories/) | Avisos, versões afetadas, correções e mitigação documentada. |
| Código e bugs | [NLnetLabs/unbound](https://github.com/NLnetLabs/unbound) | Issues, commits, testes e releases; distinguir proposta de correção lançada. |
| Debian | [Security Tracker — unbound](https://security-tracker.debian.org/tracker/source-package/unbound) | Status do pacote por distribuição e backports. |
| Ubuntu | [Ubuntu CVEs](https://ubuntu.com/security/cves) | Consultar CVE e release exatos; verificar o aviso correspondente. |

Para outro fornecedor, consulte seu próprio tracker e notas da release. Não aplique status Debian a Ubuntu, FreeBSD, pfSense, OPNsense ou imagens de terceiros.

## Material de terceiros avaliado

- [chrishuffman5/domain-expert — unbound](https://github.com/chrishuffman5/domain-expert/tree/main/plugins/networking/skills/unbound): útil para mapear temas, mas a revisão encontrou problemas conceituais sobre DNSSEC/encaminhamento, respip/ECS e slabs. Esta skill foi escrita com instruções próprias e fontes oficiais; não incorpora aquela configuração como autoridade.
- [mtgibbs/pi-cluster — dns-ops](https://github.com/mtgibbs/pi-cluster/blob/main/.claude/skills/dns-ops/SKILL.md): referência de diagnóstico de cache e múltiplas réplicas; seus endereços, ferramentas e decisões particulares de infraestrutura não são defaults aqui.
- [fritterhoff/unbound-firewall](https://github.com/fritterhoff/unbound-firewall): exemplo de geração de RPZ, não garantia de manutenção ou adequação a produção.

## Como manter

Quando uma opção mudar, atualize a instrução e a referência específica; preserve o comportamento necessário para instalações antigas identificadas. Acrescente conhecimento por evidência de uso, evitando acumular receitas universais para um único incidente.

Não congele uma “última versão”, uma lista definitiva de CVEs ou um patch ainda não lançado como recomendação permanente. Consulte o estado atual ao executar a tarefa e registre a data no relatório dessa execução.
