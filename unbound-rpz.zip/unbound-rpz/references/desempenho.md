# Desempenho: medir, ajustar e demonstrar

## 1. Definir a meta

Distinga latência, capacidade, memória, estabilidade e tempo de atualização RPZ. Uma mudança pode melhorar uma métrica e piorar outra. Defina carga representativa, janela de observação e orçamento de recursos antes de alterar parâmetros.

Registre antes e depois, conforme ferramentas disponíveis:

| Métrica | Como ajuda a decidir |
| --- | --- |
| QPS e distribuição por tipo/transporte | Quantifica a carga; número de clientes sozinho não dimensiona servidor. |
| Latência p50, p95 e p99 | Média pode esconder a cauda que afeta clientes. |
| Cache hits/misses e latência de recursão | Separa desempenho do cache e do caminho upstream. |
| SERVFAIL, timeouts e retransmissões | Evita chamar perda de respostas de ganho de velocidade. |
| CPU, RSS, swap e throttling | Mostra limites reais do processo/container. |
| Drops UDP, buffers e descritores | Identifica filas e limites do sistema. |
| Duração, RSS e falhas na carga RPZ | Listas grandes podem causar pausas e picos transitórios. |

Se o controle remoto já estiver configurado, `unbound-control stats_noreset` permite coletar sem zerar contadores; use a configuração e o destino corretos. Calcule taxas pelas diferenças entre duas amostras, verificando reinício/reset entre elas. Não exponha a interface de controle para coletar métricas.

## 2. Decisões por parâmetro

### Threads e slabs

Considere núcleos realmente disponíveis, afinidade e limites de CPU/cgroup. A recomendação oficial de usar os núcleos disponíveis é um ponto de partida para carga elevada, não obrigação de maximizar threads num resolver doméstico.

Slabs particionam caches compartilhados para reduzir contenção. Nas versões atuais, valores não definidos podem ser ajustados automaticamente a partir das threads; confira versão e configuração antes de fixá-los. Quando explícitos, precisam respeitar as restrições documentadas, incluindo potências de dois. Não crie uma tabela universal de threads por clientes.

### Cache e memória

RRset cache aproximadamente duas vezes maior que message cache é uma referência de dimensionamento, não uma condição sintática. Orce também allocator, key/infra caches, threads, conexões, RPZs e memória temporária durante recargas. A soma dos valores de cache não é o RSS esperado.

Aumente cache se houver pressão/evicção e RAM disponível; com pouca memória, isso pode provocar swap/OOM e piorar o serviço. Meça o comportamento, não apenas a configuração.

### UDP, conexões e limites

No Linux, avalie `so-reuseport` em carga multithread e confirme suporte/estado. Ajuste buffers somente quando houver motivo; confira limites de `net.core.rmem_max` e `net.core.wmem_max`, logs e drops. Não aplique um conjunto genérico de sysctls.

`outgoing-range` e `num-queries-per-thread` devem caber no backend de eventos, limites de descritores, memória e demanda. Confirme build/backend com `unbound -V` e evidências do processo. Não copie `8192/4096` universalmente nem trate outgoing-range como ajuste exclusivo de TCP.

### Prefetch e respostas expiradas

`prefetch` pode reduzir misses para nomes populares ao custo de consultas e trabalho adicionais. `prefetch-key` altera a busca de material DNSSEC; avalie conforme carga.

`serve-expired` é uma escolha de continuidade versus atualidade. Documente limite de idade, TTL devolvido, tempo de espera e comportamento da versão instalada. Os defaults e a preferência por tentar atualizar antes de devolver dado antigo mudaram entre versões. Não diga que a opção sempre responde imediatamente.

Verifique também se há configuração que renova a janela de dados expirados após falhas. Cache antigo pode produzir aparência de sucesso durante incidente; meça resolução fresca separadamente.

### TTL, logs e cache externo

Elevar `cache-min-ttl` pode contrariar intenção de TTLs curtos e atrasar mudanças/failover. Não use como otimização automática. Preserve os TTLs de origem salvo necessidade demonstrada.

Logs por consulta, logs RPZ e estatísticas extensas precisam de orçamento e período de uso. Redis/cachedb acrescenta latência, dependência e manutenção; só introduza se o problema justificar e se a build suportar. Cache externo não é requisito para bom desempenho.

## 3. Avaliar RPZ em grande escala

Meça quantidade efetiva de regras, distribuição de gatilhos, sobreposição de feeds e atualização/reload. Uma lista maior pode aumentar custo e falsos positivos sem trazer bloqueios úteis.

Deduplicação deve preservar ações e precedência. Se duas listas têm ações diferentes, combinar e deduplicar sem critério altera a política. Para bugs de carregamento e pausas, consulte release notes e issues oficiais aplicáveis à versão/pacote. Uma PR aberta ou um benchmark de terceiros não comprova correção disponível no pacote instalado.

## 4. Comparação válida

1. Reproduza a mesma carga e distribuição; identifique se cache está frio ou quente.
2. Mude um grupo coerente de parâmetros por vez.
3. Compare latências, sucesso e recursos sob condições semelhantes.
4. Inclua duração/pico de atualização RPZ se esse é o problema investigado.
5. Aceite a mudança somente se atingir a meta sem regressão material nas funções exigidas.

Use ferramenta de carga apropriada somente contra destino autorizado, com limite de QPS, duração e condição de interrupção. Consultas `dig` isoladas são sondagens, não teste de capacidade. Não faça stress test em produção implicitamente ao receber pedido de otimização.

Ao relatar ganho, inclua medição inicial/final e metodologia. Se só houve revisão de configuração, diga que há uma melhoria proposta, ainda sem ganho comprovado.
