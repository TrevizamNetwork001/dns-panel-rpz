# RPZ: regras, exceções, atualização e testes

## Conteúdo

1. Modelo de políticas e precedência
2. Exemplo de laboratório
3. Testes e observação
4. Atualização confiável de listas
5. Erros frequentes

## 1. Modelo de políticas e precedência

Uma RPZ é uma zona de política. Gatilhos e ações têm convenções próprias; lista hosts, lista de URLs, conjunto de domínios e arquivo RPZ não são formatos intercambiáveis.

A cadeia básica para um resolver com validação é:

```text
server:
    module-config: "respip validator iterator"
```

Se já existirem `cachedb`, `python`, `dns64` ou outros módulos, não substitua a cadeia cegamente. Confira combinações e ordem no manual da instalação. Em particular, `respip` deve preceder `dns64` quando combinados.

As RPZs são avaliadas na ordem configurada. O primeiro casamento encerra a busca nas RPZs seguintes, inclusive com PASSTHRU. Coloque exceções antes das listas que elas precisam sobrepor; a regra só vale para o gatilho/origem em que ela se aplica.

| Ação | Registro na zona | Significado |
| --- | --- | --- |
| NXDOMAIN | `CNAME .` | Responde que o nome não existe. |
| NODATA | `CNAME *.` | Responde sem dados do tipo pedido. |
| PASSTHRU | `CNAME rpz-passthru.` | Não aplica as políticas RPZ seguintes para esse casamento. |
| DROP | `CNAME rpz-drop.` | Não responde; timeouts são consequência esperada. |
| TCP-only | `CNAME rpz-tcp-only.` | Induz uso de TCP; teste UDP e a consulta TCP seguinte. |
| Dados locais | RR do tipo pretendido | Substitui dados conforme semântica documentada. |

Gatilhos: QNAME, endereço do cliente, IP da resposta, nome do NS e IP do NS. A codificação de rede nos gatilhos IP não é a notação CIDR convencional. Consulte exemplos oficiais antes de gerar regras IP; teste também os limites de cada prefixo.

## 2. Exemplo de laboratório

Exemplo de duas zonas locais para um laboratório Linux **sem chroot**, com nomes reservados. Adapte caminhos ao destino e monte estes trechos na configuração completa existente. Não desative o chroot de produção para copiar este exemplo.

```text
server:
    module-config: "respip validator iterator"

rpz:
    name: "allow.rpz.test."
    zonefile: "/etc/unbound/rpz/allow.zone"

rpz:
    name: "block.rpz.test."
    zonefile: "/etc/unbound/rpz/block.zone"
```

Arquivo `allow.zone`:

```dns
$ORIGIN allow.rpz.test.
$TTL 60
@ IN SOA localhost. hostmaster.localhost. (
    1 3600 600 86400 60
)
@ IN NS localhost.
allowed.demo.test IN CNAME rpz-passthru.
```

Arquivo `block.zone`:

```dns
$ORIGIN block.rpz.test.
$TTL 60
@ IN SOA localhost. hostmaster.localhost. (
    1 3600 600 86400 60
)
@ IN NS localhost.
demo.test IN CNAME .
*.demo.test IN CNAME .
```

Pontos necessários para entender o exemplo:

- Os proprietários `demo.test` e `*.demo.test` são relativos à origem da RPZ. O mecanismo RPZ interpreta esses proprietários como gatilhos. Adicionar ponto final ao proprietário muda seu nome absoluto e pode colocá-lo fora da zona.
- Os alvos especiais de CNAME têm ponto final. `rpz-passthru` sem ponto passaria a ser relativo à origem e mudaria a ação.
- Nome exato e wildcard são regras distintas. Não presuma que `*.demo.test` cobre o próprio `demo.test`.
- A exceção acima cobre `allowed.demo.test`, não todos os seus subdomínios. Acrescente regra wildcard de exceção somente se essa abrangência for desejada.
- `.test` é reservado; PASSTHRU não cria dados DNS. Para provar resolução permitida, use uma zona controlada resolvível ou o fixture isolado abaixo.

Fixture opcional **apenas para uma instância de teste isolada**: adicione uma zona autoritativa local que devolva A para nomes sob `demo.test`. Isso permite distinguir exceção de NXDOMAIN natural sem depender da Internet. O Unbound possui uma zona local padrão para `.test` que responde NXDOMAIN; torne apenas `demo.test` transparente no laboratório para permitir processamento pela zona autoritativa e RPZ. Sem isso, o teste pode medir a política local padrão em vez da RPZ.

```text
server:
    local-zone: "demo.test." transparent

auth-zone:
    name: "demo.test."
    zonefile: "/caminho/isolado/demo.test.zone"
    for-downstream: yes
    for-upstream: no
```

Conteúdo de `demo.test.zone`:

```dns
$ORIGIN demo.test.
$TTL 60
@ IN SOA ns.demo.test. hostmaster.demo.test. (
    1 3600 600 86400 60
)
@ IN NS ns.demo.test.
ns IN A 192.0.2.53
@ IN A 192.0.2.10
* IN A 192.0.2.10
```

Esse fixture não prova recursão externa nem DNSSEC; serve para exercitar RPZ QNAME. Confirme o suporte a auth-zone na versão testada e faça o carregamento real antes de interpretar resultados.

## 3. Testes e observação

| Consulta A no fixture | Expectativa |
| --- | --- |
| `demo.test` | NXDOMAIN pela regra exata. |
| `blocked.demo.test` | NXDOMAIN pela regra wildcard. |
| `allowed.demo.test` | NOERROR e A `192.0.2.10` pela exceção anterior à blocklist. |
| `child.allowed.demo.test` | Continua bloqueado, porque não há wildcard de exceção. |

Teste novamente após atualizar arquivos, confirmando serial e logs de carregamento. Faça também testes AAAA e TCP quando relevantes. Registre qual política foi aplicada, não apenas o status.

Validação deste exemplo: em 2026-11-04, o fixture completo passou em `unbound-checkconf` e nas quatro consultas A da tabela, usando Unbound 1.26.2 em uma instância temporária na porta UDP 18535. Esse teste comprova os casos QNAME descritos; não é auditoria de produção, benchmark, teste de DNSSEC ou garantia para outras versões. O laboratório expôs a necessidade de tornar `demo.test` transparente, já incorporada acima.

Para observar um feed novo sem executar suas ações, quando suportado, use na RPZ em avaliação:

```text
    rpz-action-override: disabled
    rpz-log: yes
    rpz-log-name: "avaliacao-feed"
```

`disabled` permite continuar nas zonas seguintes; `passthru` é um casamento que as interrompe. Não use PASSTHRU como substituto de modo de observação. Defina período e volume de logs e remova a instrumentação quando concluir. Logs podem registrar domínios consultados.

Estatísticas por ação RPZ podem exigir `extended-statistics`. Confira nomes disponíveis em `stats_noreset` e o custo da instrumentação na versão instalada.

## 4. Atualização confiável de listas

Escolha o método conforme o fornecedor: transferência DNS AXFR/IXFR ou download de zona/lista. Transferências incrementais podem reduzir trabalho quando suportadas, mas confirme atualização efetiva e regras do fornecedor. Não invente suporte a TSIG, TLS ou outro mecanismo sem verificar a implementação e a configuração disponíveis.

Para atualização por arquivo, implemente estes estados:

1. **Obter:** timeout, verificação TLS e política clara de redirecionamento; não execute conteúdo baixado. Não registre tokens da URL.
2. **Preparar:** arquivo temporário fora dos globs ativos, preferencialmente no mesmo filesystem do destino para promoção por rename. Impeça concorrência entre atualizadores.
3. **Conferir:** código de sucesso, conteúdo não vazio, ausência de HTML de erro, origem esperada e formato. Compare contagem e tamanho com o histórico; limites precisam ser adequados ao feed, não números universais.
4. **Converter, se necessário:** normalizar domínios/IDNA com biblioteca apropriada, remover comentários e duplicatas sem destruir semântica; distinguir URL, hosts e RPZ. Não remover regras IP ou exceções como se fossem lixo.
5. **Validar:** SOA, serial, NS, origem, proprietários e alvos; carregar com Unbound isolado quando necessário. Contagem de linhas sozinha não mede quantidade de regras.
6. **Promover:** preservar última versão funcional, dono e permissões; trocar arquivo validado e recarregar pelo mecanismo suportado. Rename é atômico para um arquivo, não para várias zonas juntas.
7. **Comprovar:** logs de carregamento, regras amostradas, bloqueios esperados e exceções continuam corretos.
8. **Recuperar:** falha de download ou validação mantém a versão funcional; falha após promoção restaura a anterior e repete testes. Reporte a falha e a idade do feed em uso.

Não substitua uma lista funcional por conteúdo vazio como reação a indisponibilidade. Para múltiplos arquivos que precisam mudar juntos, use uma estratégia de geração consistente compatível com os includes e o gerenciador de configuração. Registre data da última atualização bem-sucedida, fonte, serial/hash e resultado; política de retenção deve considerar espaço em disco.

## 5. Erros frequentes

- Substituir blocklist inteira sem validar o download.
- Aplicar exceção depois da zona que já bloqueia o nome.
- Ler arquivo candidato e promover outro arquivo.
- Ignorar que proxy/NAT altera o IP visto por gatilhos de cliente.
- Esperar política por cliente quando todos chegam como o mesmo proxy.
- Usar somente a consulta ao frontend, cujo cache pode esconder a nova política.
- Misturar comentários `#` de unbound.conf com sintaxe de zona DNS; arquivos de zona usam `;` para comentários.
- Usar log de bloqueio como prova de saúde de todo o resolver.
- Confundir política intencional de reescrita com falha de DNSSEC sem consultar comportamento documentado da versão.
