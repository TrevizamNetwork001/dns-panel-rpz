# Operação, configuração e diagnóstico

## Conteúdo

1. Inventário e origem da configuração
2. Preparação e validação
3. Testes funcionais
4. Diagnóstico por sintoma
5. Aplicação, reversão e registro

## 1. Inventário e origem da configuração

Os exemplos abaixo pressupõem Linux com systemd. Confirme o nome do serviço antes de usá-los. Em containers, execute a leitura no container correto; em BSD/appliances, use as ferramentas equivalentes.

```bash
unbound -V
systemctl cat unbound
systemctl show unbound -p ExecStart -p MainPID -p User -p Group -p MemoryMax -p LimitNOFILE
systemctl status unbound --no-pager
ss -lntup
```

`unbound -V` descreve o executável encontrado no PATH: ele pode diferir daquele iniciado pelo serviço. Compare ExecStart, executável do processo, mounts e imagem. Registre se o pacote foi atualizado mas o processo ainda não reiniciou.

Localize includes a partir do arquivo principal encontrado. Leia arquivos incluídos sem despejar chaves privadas, credenciais de feeds, dados de clientes ou certificados privados na conversa. Registre duplicidades, arquivos gerados e regras que dependam de ordenação. Não presuma que a configuração está em `/etc/unbound` ou que todo arquivo `.conf` é carregado.

Verifique:

- Porta e endereço realmente escutados; conflitos com Pi-hole, dnsmasq, systemd-resolved e outro Unbound.
- ACLs de clientes e firewall. Interface em todos os endereços não equivale a autorização de recursão para todos; confirme as duas camadas.
- Permissões do usuário do serviço, travessia de diretórios, chroot, AppArmor/SELinux e volumes.
- Trust anchor gravável quando há atualização automática, relógio correto e certificados CA quando usados.
- Loops: Unbound encaminhando para Pi-hole que encaminha ao mesmo Unbound; hostname do upstream dependendo da própria zona encaminhada.
- Recursão: saída UDP e TCP DNS. Encaminhamento TLS: conectividade, SNI/nome de autenticação e cadeia de confiança.

## 2. Preparação e validação

Antes da edição, registre os arquivos e o estado gerenciado. Preserve permissões e donos; um backup de configuração pode conter dados sensíveis e precisa de proteção equivalente.

Exemplo de variável para **um arquivo candidato já preparado**:

```bash
candidate_conf='/caminho/real/da/candidata/unbound.conf'
unbound-checkconf "$candidate_conf"
```

O caminho é ilustrativo e deve ser substituído. Valide o principal, não apenas um fragmento. Um principal temporário que ainda inclua arquivos de produção não testa fragmentos candidatos. Revise também includes absolutos, `directory`, chroot e caminhos de zonas.

Critérios para prosseguir:

- O validador retornou código zero; warnings foram explicados.
- Binário do validador corresponde à instalação alvo.
- Arquivos necessários existem e são acessíveis ao usuário efetivo do daemon.
- Configuração RPZ passou pelo carregamento quando a mudança a exigir.
- Há backup recuperável e procedimento de reversão compatível com o gerenciador.

Se houver validador de zona disponível, use-o como verificação adicional de sintaxe. Um zone checker de outro produto não comprova a interpretação de gatilhos e ações pelo Unbound. Teste o carregamento real e as respostas.

## 3. Testes funcionais

Use nomes de teste controlados ou confirmados na data da execução. Não dependa indefinidamente de um domínio público conhecido como assinado ou inválido: sua configuração pode mudar.

```bash
resolver_addr='127.0.0.1'
resolver_port='53'
test_name='nome-real-do-teste.example'
dig @"$resolver_addr" -p "$resolver_port" "$test_name" A +dnssec +time=2 +tries=1
dig @"$resolver_addr" -p "$resolver_port" "$test_name" AAAA +dnssec +time=2 +tries=1
dig @"$resolver_addr" -p "$resolver_port" "$test_name" A +tcp +time=2 +tries=1
```

Substitua `test_name`; `.example` é reservado e não fornece teste público de resolução. Evite `+short` quando precisar interpretar status, flags, TTLs e autoridade. Tempos e tentativas acima são apenas limites de uma sondagem, não benchmark.

| Caso | Resultado esperado e interpretação |
| --- | --- |
| Domínio válido permitido | Resposta adequada ao tipo consultado; ausência de AAAA pode ser NODATA legítimo. |
| Nome inexistente controlado | NXDOMAIN esperado; não confundir com falha geral do resolver. |
| Zona assinada válida | Validação bem-sucedida; `AD` em consulta direta pode dar evidência, conforme flags e configuração. |
| Zona deliberadamente inválida | SERVFAIL pela validação; confirme motivo nos logs e compare com CD somente no diagnóstico. |
| Domínio interno | Resposta esperada no cliente/rede correspondente; sem encaminhamento indevido. |
| RPZ bloqueada | Ação configurada; confira nome exato e wildcard. |
| RPZ com exceção | PASSTHRU impede aplicação das RPZs seguintes; resposta final depende das outras etapas do resolver. |
| UDP e TCP | Ambos funcionam onde são necessários; TCP quebrado pode causar falhas seletivas. |
| Cada réplica e caminho do cliente | Teste todos os servidores antes de concluir que o serviço está saudável. |

Uma consulta direta ainda pode usar o cache do Unbound. Para observar recursão fresca, use nomes únicos sob zona de teste controlada ou, quando autorizado e necessário, limpeza seletiva de uma zona. Não esvazie o cache inteiro como primeiro passo de diagnóstico.

## 4. Diagnóstico por sintoma

```bash
journalctl -u unbound --since '30 minutes ago' --no-pager
```

Adapte janela e unidade. Aumente verbosidade apenas pelo tempo necessário e restaure-a depois. Logs por consulta podem custar CPU/disco e revelar navegação.

| Sintoma | Investigar primeiro | Evidência para distinguir causas |
| --- | --- | --- |
| Timeout | Serviço, porta, rota, firewall e transporte | Consulta no host e no cliente; sockets e logs no mesmo horário. |
| REFUSED | ACL, interface, política e origem vista pelo servidor | IP efetivo após proxy/NAT; acesso deliberadamente negado. |
| SERVFAIL | DNSSEC, upstream, delegação, timeout e limites | Logs, relógio, trust anchor, consulta comparativa com CD. |
| Funciona em Pi-hole e falha no Unbound | Cache de Pi-hole ou stale | Consulte diretamente cada Unbound e investigue atualização do cache. |
| Apenas algumas redes falham | ACLs, tags, views, NAT e IPv6 | Repita o mesmo teste das origens afetadas. |
| RPZ sem efeito | Cadeia de módulos, ordem, gatilho e atualização | Carregamento, serial, regra exata, tags e política aplicada. |
| Falha após recarga | Erro de carregamento, arquivo, memória ou bug | Logs imediatamente antes/depois, RSS e estado do processo. |
| Latência alta | Cache miss, perda UDP, TCP, upstream e saturação | Separe consultas frias/quentes e correlacione com recursos. |

Resolver com `+cdflag` após falhar sem CD sugere envolvimento de validação, mas não identifica sozinho a causa. Verifique cadeia DNSSEC, validade das assinaturas, relógio e trust anchors. Não transforme esse teste em `val-permissive-mode` ou `domain-insecure` geral.

## 5. Aplicação, reversão e registro

Escolha a operação suportada e leia a documentação da versão:

- `reload` relê configuração e normalmente esvazia o cache.
- `reload_keep_cache` tenta preservar cache e possui restrições, incluindo alteração de tamanho de cache e número de threads.
- Recursos recentes de recarga não devem ser presumidos disponíveis, estáveis ou sem consumo transitório relevante.
- Mudança de pacote/binário pode exigir reinício para entrar em execução.
- Unidade systemd, frontend de appliance e operador Kubernetes podem ter semântica diferente: confira a ação real.

Não encadeie aplicação após uma validação falha. Depois de aplicar, teste pelo mesmo caminho do incidente e registre a versão em execução. Se houver regressão, restaure arquivos/manifests e aplique a restauração pelo mesmo gerenciador; em seguida, repita validação e testes críticos. Para atualização de pacote, a reversão pode requerer versão anterior disponível e compatibilidade de configuração — planeje antes, sem prometer downgrade universal.

O registro final deve conter: problema, causa confirmada ou hipótese, arquivos alterados, diferença relevante, comandos e resultados, impacto observado, reversão e pendências. Não declare teste executado quando apenas forneceu o comando.
